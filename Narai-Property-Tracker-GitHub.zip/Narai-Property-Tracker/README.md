# Narai Property Tracker

Dashboard for tracking annual content progress and social growth goals.

## Run locally

```bash
npm install
npm start
```

Open `http://localhost:4173`.

## Deploy on Netlify

Deploy the whole repository. Netlify uses `netlify.toml` and `netlify/functions/entries.mjs` for shared data storage.

Do not change `STORE_NAME` or `ENTRIES_KEY` in `netlify/functions/entries.mjs` if you want to keep existing production data.
