# Narai Property Tracker - GitHub Pages + Supabase

Upload this folder to GitHub Pages. CSS and app code are bundled into one index.html. Data sync uses Supabase REST API.

Supabase table required: public.tracker_store with row id = main.
